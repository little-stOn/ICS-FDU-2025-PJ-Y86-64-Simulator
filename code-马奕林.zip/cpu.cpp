#include "cpu.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <set>
#include <algorithm>
#include <cmath>
#include <numeric>

using namespace std;

const string REG_NAMES[] = {
    "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
    "r8", "r9", "r10", "r11", "r12", "r13", "r14"};

// Global mutex to ensure JSON output doesn't interleave if multiple cores print
std::mutex io_mutex;

// ==========================================
// SharedMemory Implementation
// ==========================================

SharedMemory::SharedMemory() {}

uint8_t SharedMemory::get_byte(uint64_t addr, bool &error)
{
    std::lock_guard<std::recursive_mutex> lock(mtx);
    if (addr >= MEM_SIZE)
    {
        error = true;
        return 0;
    }
    if (mem.find(addr) != mem.end())
    {
        return mem[addr];
    }
    return 0;
}

void SharedMemory::set_byte(uint64_t addr, uint8_t val, bool &error)
{
    std::lock_guard<std::recursive_mutex> lock(mtx);
    if (addr >= MEM_SIZE)
    {
        error = true;
        return;
    }
    mem[addr] = val;
}

uint64_t SharedMemory::get_word(uint64_t addr, bool &error)
{
    std::lock_guard<std::recursive_mutex> lock(mtx);
    uint64_t val = 0;
    for (int i = 0; i < 8; ++i)
    {
        uint64_t b = get_byte(addr + i, error);
        val |= (b << (i * 8));
    }
    return val;
}

void SharedMemory::set_word(uint64_t addr, int64_t val, bool &error)
{
    std::lock_guard<std::recursive_mutex> lock(mtx);
    uint64_t uval = (uint64_t)val;
    for (int i = 0; i < 8; ++i)
    {
        set_byte(addr + i, (uval >> (i * 8)) & 0xFF, error);
    }
}

void SharedMemory::print_json_content(std::ostream &os)
{
    std::lock_guard<std::recursive_mutex> lock(mtx);

    std::set<uint64_t> aligned_addrs;
    for (auto const &[addr, val] : mem)
    {
        aligned_addrs.insert(addr & ~0x7ULL);
    }

    bool first_mem = true;
    for (uint64_t addr : aligned_addrs)
    {
        uint64_t val_u = 0;
        for (int i = 0; i < 8; ++i)
        {
            if (mem.count(addr + i))
                val_u |= ((uint64_t)mem.at(addr + i) << (i * 8));
        }
        int64_t val = (int64_t)val_u;

        if (val != 0)
        {
            if (!first_mem)
                os << ",";
            os << endl
               << "      \"" << addr << "\": " << val;
            first_mem = false;
        }
    }
}

// ==========================================
// L1Cache Implementation with Write-Back
// ==========================================

L1Cache::L1Cache(SharedMemory &mem_ref) : memory(mem_ref)
{
    hits = 0;
    misses = 0;
    // Initialize all cache lines
    for (int i = 0; i < NUM_LINES; ++i)
    {
        lines[i].valid = false;
        lines[i].dirty = false;
        lines[i].tag = 0;
    }
}

// 根据索引和标签计算块地址
uint64_t L1Cache::get_block_addr(uint64_t index, uint64_t tag)
{
    return (tag << (LINE_BITS + OFFSET_BITS)) | (index << OFFSET_BITS);
}

// 从内存加载缓存行
void L1Cache::load_line(uint64_t block_addr, uint64_t index)
{
    bool error = false;

    // 如果需要替换的缓存行是脏的，先写回
    if (lines[index].valid && lines[index].dirty)
    {
        write_back_line(index);
    }

    // 从内存加载数据到缓存行
    for (int i = 0; i < 8; ++i)
    {
        lines[index].data[i] = memory.get_byte(block_addr + i, error);
    }
    lines[index].tag = block_addr >> (LINE_BITS + OFFSET_BITS);
    lines[index].valid = true;
    lines[index].dirty = false; // 新加载的行是干净的

    if (error)
    {
        cerr << "Cache: Memory load error at 0x" << hex << block_addr << dec << endl;
    }
}

// 写回单个脏缓存行到内存
void L1Cache::write_back_line(uint64_t index)
{
    if (!lines[index].valid || !lines[index].dirty)
        return;

    bool error = false;
    uint64_t block_addr = get_block_addr(index, lines[index].tag);

    // 将缓存行数据写回内存
    for (int i = 0; i < 8; ++i)
    {
        memory.set_byte(block_addr + i, lines[index].data[i], error);
    }

    if (error)
    {
        cerr << "Cache: Memory write-back error at 0x" << hex << block_addr << dec << endl;
    }

    // 标记为干净
    lines[index].dirty = false;
}

// 写回所有脏缓存行
void L1Cache::write_back_all()
{
    std::lock_guard<std::mutex> lock(mtx);

    for (uint64_t i = 0; i < NUM_LINES; ++i)
    {
        if (lines[i].valid && lines[i].dirty)
        {
            write_back_line(i);
        }
    }
}

uint8_t L1Cache::get_byte(uint64_t addr, bool &error)
{
    std::lock_guard<std::mutex> lock(mtx);
    if (addr >= memory.MEM_SIZE)
    {
        error = true;
        return 0;
    }

    uint64_t offset = addr & 0x7;
    uint64_t index = (addr >> OFFSET_BITS) & (NUM_LINES - 1);
    uint64_t tag = addr >> (LINE_BITS + OFFSET_BITS);
    uint64_t block_addr = addr & ~0x7ULL;

    if (lines[index].valid && lines[index].tag == tag)
    {
        // Cache hit
        hits++;
        return lines[index].data[offset];
    }
    else
    {
        // Cache miss
        misses++;
        load_line(block_addr, index);
        return lines[index].data[offset];
    }
}

void L1Cache::set_byte(uint64_t addr, uint8_t val, bool &error)
{
    std::lock_guard<std::mutex> lock(mtx);
    if (addr >= memory.MEM_SIZE)
    {
        error = true;
        return;
    }

    uint64_t offset = addr & 0x7;
    uint64_t index = (addr >> OFFSET_BITS) & (NUM_LINES - 1);
    uint64_t tag = addr >> (LINE_BITS + OFFSET_BITS);
    uint64_t block_addr = addr & ~0x7ULL;

    // 检查是否命中
    if (lines[index].valid && lines[index].tag == tag)
    {
        // Cache hit - write to cache only, mark dirty
        lines[index].data[offset] = val;
        lines[index].dirty = true; // 标记为脏
        hits++;
    }
    else
    {
        // Cache miss - load line then write
        misses++;
        load_line(block_addr, index);
        lines[index].data[offset] = val;
        lines[index].dirty = true; // 标记为脏
    }

    // 在写回策略中，不立即写回内存
    // 只在缓存行被替换或程序结束时才写回
}

uint64_t L1Cache::get_word(uint64_t addr, bool &error)
{
    uint64_t val = 0;
    for (int i = 0; i < 8; ++i)
    {
        uint64_t b = get_byte(addr + i, error);
        val |= (b << (i * 8));
    }
    return val;
}

void L1Cache::set_word(uint64_t addr, int64_t val, bool &error)
{
    uint64_t uval = (uint64_t)val;
    for (int i = 0; i < 8; ++i)
    {
        set_byte(addr + i, (uval >> (i * 8)) & 0xFF, error);
    }
}

void L1Cache::print_report()
{
    uint64_t total_accesses = hits + misses;
    double hit_rate = 0.0;
    if (total_accesses > 0)
    {
        hit_rate = (double)hits / total_accesses;
    }

    // 统计脏行数量
    int dirty_count = 0;
    for (int i = 0; i < NUM_LINES; ++i)
    {
        if (lines[i].valid && lines[i].dirty)
            dirty_count++;
    }

    // Output cache report to standard error to keep JSON output pure
    cerr << "--- L1 Cache Report (Write-Back) ---" << endl;
    cerr << "Total Accesses: " << total_accesses << endl;
    cerr << "Hits: " << hits << endl;
    cerr << "Misses: " << misses << endl;
    cerr << "Hit Rate: " << fixed << setprecision(4) << hit_rate * 100.0 << "%" << endl;
    cerr << "Dirty Lines: " << dirty_count << endl;
    cerr << "------------------------------------" << endl;
}

void L1Cache::print_memory_json(std::ostream &os)
{
    // 在输出JSON前，确保所有脏行都已写回
    write_back_all();
    memory.print_json_content(os);
}

// ==========================================
// CPU Implementation
// ==========================================

CPU::CPU(L1Cache &cache_ref) : cache(cache_ref)
{
    pc = 0;
    for (int i = 0; i < 15; ++i)
        reg[i] = 0;
    cc.zf = true;
    cc.sf = false;
    cc.of = false;
    stat = STAT_AOK;

    // ILP Initialization
    std::fill(reg_last_write_id, reg_last_write_id + 15, 0ULL);
    mem_last_write_id.clear();
    instr_id_counter = 0;
    total_instr = 0;
    total_logic_cycles = 0;
}

// io & parsing
void CPU::load_io()
{
    string line;
    while (getline(cin, line))
    {
        parse_line(line);
    }
}

void CPU::parse_line(const string &line)
{
    size_t pipe_pos = line.find('|');
    string content = (pipe_pos == string::npos) ? line : line.substr(0, pipe_pos);

    size_t colon_pos = content.find(':');
    if (colon_pos == string::npos)
        return;

    string addr_str = content.substr(0, colon_pos);
    string bytes_str = content.substr(colon_pos + 1);

    auto trim = [](string &s)
    {
        if (s.empty())
            return;
        s.erase(0, s.find_first_not_of(" \t"));
        s.erase(s.find_last_not_of(" \t") + 1);
    };
    trim(addr_str);
    trim(bytes_str);

    if (addr_str.empty() || bytes_str.empty())
        return;

    try
    {
        uint64_t addr = stoull(addr_str, nullptr, 16);

        for (size_t i = 0; i < bytes_str.length(); i += 2)
        {
            if (i + 1 >= bytes_str.length())
                break;
            string byte_hex = bytes_str.substr(i, 2);
            if (byte_hex == "  " || byte_hex.find(' ') != string::npos)
                break;
            uint8_t b = (uint8_t)stoi(byte_hex, nullptr, 16);

            bool error = false;
            // Use SharedMemory's set_byte for loading, bypassing cache during init
            cache.memory.set_byte(addr, b, error);

            addr++;
        }
    }
    catch (const std::exception &e)
    {
        return;
    }
}

// Execution Loop in Thread
void CPU::thread_entry()
{
    {
        std::lock_guard<std::mutex> lock(io_mutex);
        cout << "[" << endl;
    }

    bool first = true;

    while (stat == STAT_AOK)
    {
        step();
        print_state(first);
        first = false;
    }

    {
        std::lock_guard<std::mutex> lock(io_mutex);
        cout << endl
             << "]" << endl;
    }
}

// Public run method spawns the thread
void CPU::run()
{
    std::thread t(&CPU::thread_entry, this);
    t.join(); // Wait for the core to finish

    // 程序结束时，确保所有脏缓存行写回内存
    cache.write_back_all();

    // Print reports after execution
    cache.print_report();
    print_ilp_report();
}

// Helper to get the dependency ID (latest write) for a memory access
uint64_t CPU::get_mem_dependency_id(uint64_t addr)
{
    // Check all 8 bytes that form the 8-byte aligned word containing addr
    uint64_t aligned_addr = addr & ~0x7ULL;
    uint64_t max_id = 0;

    for (int i = 0; i < 8; ++i)
    {
        uint64_t current_addr = aligned_addr + i;
        if (mem_last_write_id.count(current_addr))
        {
            max_id = std::max(max_id, mem_last_write_id.at(current_addr));
        }
    }
    return max_id;
}

// Helper to update the dependency ID for a memory write
void CPU::update_mem_dependency_id(uint64_t addr, uint64_t instr_id)
{
    // For simplicity with the existing memory map: update the 8-byte word region.
    uint64_t aligned_addr = addr & ~0x7ULL;

    for (int i = 0; i < 8; ++i)
    {
        mem_last_write_id[aligned_addr + i] = instr_id;
    }
}

void CPU::step()
{
    // --- ILP Analysis: Start of Instruction ---
    instr_id_counter++;
    uint64_t current_instr_id = instr_id_counter;
    uint64_t max_dependency_id = 0; // The ID of the instruction this one depends on

    total_instr++;
    // --- ILP Analysis: End of Start ---

    bool imem_error = false;
    bool dmem_error = false;
    bool instr_error = false;

    // Fetch uses the cache interface
    uint64_t f_pc = pc;
    uint8_t icode_ifun = cache.get_byte(f_pc, imem_error);
    uint8_t icode = (icode_ifun >> 4) & 0xF;
    uint8_t ifun = icode_ifun & 0xF;

    uint64_t valP = f_pc + 1;

    uint8_t rA = RNONE, rB = RNONE;
    int64_t valC = 0;

    bool need_reg = (icode == 2 || icode == 3 || icode == 4 || icode == 5 ||
                     icode == 6 || icode == 0xA || icode == 0xB);
    bool need_valC = (icode == 3 || icode == 4 || icode == 5 || icode == 7 || icode == 8);

    if (need_reg)
    {
        uint8_t reg_byte = cache.get_byte(valP, imem_error);
        rA = (reg_byte >> 4) & 0xF;
        rB = reg_byte & 0xF;
        valP++;
    }

    if (need_valC)
    {
        valC = (int64_t)cache.get_word(valP, imem_error);
        valP += 8;
    }

    if (imem_error)
    {
        stat = STAT_ADR;
        return;
    }

    if (icode > 0xB)
    {
        stat = STAT_INS;
        return;
    }

    uint64_t next_pc = valP;

    // --- ILP Analysis: Data Dependency Check ---
    // Track read dependencies (RAX-R14 are 0-14)
    auto check_reg_read = [&](uint8_t reg_id)
    {
        if (reg_id != RNONE && reg_id < 15)
        {
            max_dependency_id = std::max(max_dependency_id, reg_last_write_id[reg_id]);
        }
    };

    // Track write dependencies (Register Write-After-Write is handled by current_instr_id)
    auto update_reg_write = [&](uint8_t reg_id)
    {
        if (reg_id != RNONE && reg_id < 15)
        {
            reg_last_write_id[reg_id] = current_instr_id;
        }
    };

    // Track memory read dependencies (Load-Store Dependency)
    auto check_mem_read = [&](int64_t addr)
    {
        max_dependency_id = std::max(max_dependency_id, get_mem_dependency_id(addr));
    };

    // Track memory write dependencies (Store-Load/Store-Store Dependency)
    auto update_mem_write = [&](int64_t addr)
    {
        update_mem_dependency_id(addr, current_instr_id);
    };

    // --- Dependency Analysis Per Instruction ---
    switch (icode)
    {
    case 0x0:
    case 0x1:
        break;

    case 0x2:
        check_reg_read(rA);
        update_reg_write(rB);
        break;

    case 0x3:
        update_reg_write(rB);
        break;

    case 0x4: // rmmovq (Store)
        check_reg_read(rA);
        check_reg_read(rB);
        update_mem_write(reg[rB] + valC);
        break;

    case 0x5: // mrmovq (Load)
        check_reg_read(rB);
        check_mem_read(reg[rB] + valC);
        update_reg_write(rA);
        break;

    case 0x6: // OPq
        check_reg_read(rA);
        check_reg_read(rB);
        update_reg_write(rB);
        break;

    case 0x7: // jXX
        break;

    case 0x8: // call
        check_reg_read(RSP);
        update_mem_write(reg[RSP] - 8);
        update_reg_write(RSP);
        break;

    case 0x9: // ret
        check_reg_read(RSP);
        check_mem_read(reg[RSP]);
        update_reg_write(RSP);
        break;

    case 0xA: // pushq
        check_reg_read(rA);
        check_reg_read(RSP);
        update_mem_write(reg[RSP] - 8);
        update_reg_write(RSP);
        break;

    case 0xB: // popq
        check_reg_read(RSP);
        check_mem_read(reg[RSP]);
        update_reg_write(RSP);
        update_reg_write(rA);
        break;

    default:
        break;
    }
    // --- ILP Analysis: End of Data Dependency Check ---

    // --- ILP Analysis: Logic Cycle Calculation (FIXED) ---
    // 1. 计算当前指令的最早完成周期。
    // 在理想的超标量机上，指令将在其最长依赖指令完成后的下一周期完成（假设指令延迟为 1 周期）。
    uint64_t completion_cycle = max_dependency_id + 1;

    // 2. 总逻辑周期数 (total_logic_cycles) 追踪的是关键路径的长度。
    // 每次执行，我们只更新它，如果当前指令的完成时间 (completion_cycle)
    // 超过了历史关键路径时间。
    total_logic_cycles = std::max(total_logic_cycles, completion_cycle);
    // --- ILP Analysis: End of Logic Cycle Calculation ---

    // --- Normal Execution Flow (as before) ---
    switch (icode)
    {
    case 0x0:
        stat = STAT_HLT;
        break;
    case 0x1:
        break;

    case 0x2: // rrmovq / cmovXX
    {
        bool cond = false;
        switch (ifun)
        {
        case 0:
            cond = true;
            break;
        case 1:
            cond = (cc.sf ^ cc.of) || cc.zf;
            break;
        case 2:
            cond = (cc.sf ^ cc.of);
            break;
        case 3:
            cond = cc.zf;
            break;
        case 4:
            cond = !cc.zf;
            break;
        case 5:
            cond = !(cc.sf ^ cc.of);
            break;
        case 6:
            cond = !(cc.sf ^ cc.of) && !cc.zf;
            break;
        default:
            instr_error = true;
            break;
        }
        if (cond && !instr_error)
        {
            reg[rB] = reg[rA];
        }
        break;
    }

    case 0x3:
        reg[rB] = valC;
        break;

    case 0x4: // rmmovq
    {
        int64_t addr = reg[rB] + valC;
        cache.set_word(addr, reg[rA], dmem_error);
        break;
    }

    case 0x5: // mrmovq
    {
        int64_t addr = reg[rB] + valC;
        reg[rA] = (int64_t)cache.get_word(addr, dmem_error);
        break;
    }

    case 0x6: // OPq
    {
        int64_t a = reg[rA], b = reg[rB], res = 0;
        switch (ifun)
        {
        case 0:
            res = b + a;
            cc.of = (b < 0 && a < 0 && res >= 0) || (b >= 0 && a >= 0 && res < 0);
            break;
        case 1:
            res = b - a;
            cc.of = (b < 0 && a >= 0 && res >= 0) || (b >= 0 && a < 0 && res < 0);
            break;
        case 2:
            res = b & a;
            cc.of = false;
            break;
        case 3:
            res = b ^ a;
            cc.of = false;
            break;
        default:
            instr_error = true;
            break;
        }
        if (!instr_error)
        {
            reg[rB] = res;
            cc.zf = (res == 0);
            cc.sf = (res < 0);
        }
        break;
    }

    case 0x7: // jXX
    {
        bool cond = false;
        switch (ifun)
        {
        case 0:
            cond = true;
            break;
        case 1:
            cond = (cc.sf ^ cc.of) || cc.zf;
            break;
        case 2:
            cond = (cc.sf ^ cc.of);
            break;
        case 3:
            cond = cc.zf;
            break;
        case 4:
            cond = !cc.zf;
            break;
        case 5:
            cond = !(cc.sf ^ cc.of);
            break;
        case 6:
            cond = !(cc.sf ^ cc.of) && !cc.zf;
            break;
        default:
            instr_error = true;
            break;
        }
        if (!instr_error && cond)
        {
            next_pc = valC;
        }
        break;
    }

    case 0x8: // call
    {
        int64_t val = (int64_t)valP;
        reg[RSP] -= 8;
        cache.set_word(reg[RSP], val, dmem_error);
        next_pc = valC;
        break;
    }

    case 0x9: // ret
    {
        int64_t val = (int64_t)cache.get_word(reg[RSP], dmem_error);
        reg[RSP] += 8;
        next_pc = val;
        break;
    }

    case 0xA: // pushq
    {
        int64_t val = reg[rA];
        reg[RSP] -= 8;
        cache.set_word(reg[RSP], val, dmem_error);
        break;
    }

    case 0xB: // popq
    {
        int64_t val = (int64_t)cache.get_word(reg[RSP], dmem_error);
        reg[RSP] += 8;
        reg[rA] = val;
        break;
    }

    default:
        stat = STAT_INS;
        break;
    }

    if (instr_error)
        stat = STAT_INS;
    else if (dmem_error)
        stat = STAT_ADR;

    if (stat == STAT_AOK)
    {
        pc = next_pc;
    }
}

void CPU::print_ilp_report()
{
    // Output ILP report to standard error to keep JSON output pure
    cerr << "--- ILP Analysis Report ---" << endl;
    cerr << "Total Instructions (I): " << total_instr << endl;
    cerr << "Total Logic Cycles (C): " << total_logic_cycles << endl;

    double ilp = 0.0;
    if (total_logic_cycles > 0)
    {
        ilp = (double)total_instr / total_logic_cycles;
    }

    cerr << "Dynamic ILP (I/C): " << fixed << setprecision(4) << ilp << endl;
    cerr << "---------------------------" << endl;
}

void CPU::print_state(bool first)
{
    std::lock_guard<std::mutex> lock(io_mutex);

    if (!first)
        cout << "," << endl;

    cout << "  {" << endl;

    cout << "    \"CC\": {" << endl;
    cout << "      \"OF\": " << (cc.of ? 1 : 0) << "," << endl;
    cout << "      \"SF\": " << (cc.sf ? 1 : 0) << "," << endl;
    cout << "      \"ZF\": " << (cc.zf ? 1 : 0) << endl;
    cout << "    }," << endl;

    cout << "    \"MEM\": {";

    cache.print_memory_json(cout);

    cout << "}," << endl;

    cout << "    \"PC\": " << pc << "," << endl;

    cout << "    \"REG\": {" << endl;
    for (int i = 0; i < 15; ++i)
    {
        cout << "      \"" << REG_NAMES[i] << "\": " << reg[i];
        if (i < 14)
            cout << ",";
        cout << endl;
    }
    cout << "    }," << endl;

    cout << "    \"STAT\": " << stat << endl;

    cout << "  }";
}

int main()
{
    std::ios::sync_with_stdio(false);
    cin.tie(nullptr);

    SharedMemory system_mem;
    L1Cache l1_cache(system_mem);
    CPU cpu(l1_cache);

    cpu.load_io();
    cpu.run();

    return 0;
}